import React from 'react'
// import PropTypes from 'prop-types'
import Layout from 'common/Layout'
import { Container, Row, Col } from 'react-bootstrap';
import TitleHead from 'common/TitleHead/titleHead';
import AddressHead from './addressHead';

const ContactUs = () => {
  return (
    <Layout>
        <div className="outer-body">
            <AddressHead firstTitle={"UK Address"} secondTitle={"US Address"} thirdTitle={"Contact Us"} />
            <Container className="page-content">
                <Row>
                    <Col  xs={6}>
                        <img src={"https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc39cc0dc6c0c9acef6de1a_details1.jpg"} alt="" />
                    </Col>
                    <Col  xs={6}>
                        <img src={"https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc39cee429c1a6618f7ad56_details2.jpg"} alt="" />
                    </Col>
                </Row>
            </Container>
        </div>
    </Layout>
  )
}

ContactUs.propTypes = {
}

export default ContactUs;

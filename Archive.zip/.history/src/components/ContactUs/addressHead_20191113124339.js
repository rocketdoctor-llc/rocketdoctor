import React from 'react';
import { Row, Col, Container } from 'react-bootstrap';

const TitleHead = (props) => {
    const { titleHead } = props;
    return <div className="title-wrp">
        <Container>
            <Row>
                <Col>
                    <h2 className="address-title">{titleHead || "Title"}</h2>
                </Col>
                <Col>
                    <h2 className="address-title">{titleHead || "Title"}</h2>
                </Col>
                <Col>
                    <h2 className="address-title">{titleHead || "Title"}</h2>
                </Col>
            </Row>
        </Container>
    </div>
};

export default TitleHead;

import React from 'react';
import { Row, Col, Container } from 'react-bootstrap';

const TitleHead = (props) => {
    const { firstTitle, secondTitle, thirdTitle } = props;
    return <div className="title-wrp">
        <Container>
            <Row>
                <Col xs={4}>
                    <h2 className="address-title">{titleHead || "Title"}</h2>
                </Col>
                <Col xs={4}>
                    <h2 className="address-title">{titleHead || "Title"}</h2>
                </Col>
                <Col xs={4}>
                    <h2 className="address-title">{titleHead || "Title"}</h2>
                </Col>
            </Row>
        </Container>
    </div>
};

export default TitleHead;

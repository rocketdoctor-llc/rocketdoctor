import React from 'react'
// import PropTypes from 'prop-types'
import Layout from 'common/Layout'
import { Container, Row, Col } from 'react-bootstrap';
import TitleHead from 'common/TitleHead/titleHead';
import AddressHead from './addressHead';

const ContactUs = () => {
  return (
    <Layout>
        <div className="outer-body">
            <AddressHead firstTitle={"UK Address"} secondTitle={"US Address"} thirdTitle={"Contact Us"} />
            <Container className="page-content">
                <Row>
                    <Col  xs={6}>
                        <h2>Send Your Queries</h2>
                        <div>
                            Form Will be display here
                        </div>
                    </Col>
                    <Col  xs={6}>
                        
                    </Col>
                </Row>
            </Container>
        </div>
    </Layout>
  )
}

ContactUs.propTypes = {
}

export default ContactUs;

import React from 'react';
import PropTypes from 'prop-types';
import AuthLayout from 'shared/AuthLayout';
import AuthSideBar from "shared/AuthSideBar";
import { Row, Col } from 'react-bootstrap';
import SignInComp from "./signInComp";


const SignIn = () => {
  return (
    <AuthLayout>
      <Row>
        <Col xs={{ span: 6}}>
          <SignInComp />
        </Col>
        <Col xs={{ span: 6}}>
          <AuthSideBar />
        </Col>
      </Row>
    </AuthLayout>
  )
}

SignIn.propTypes = {
  getList: PropTypes.func
}

export default SignIn

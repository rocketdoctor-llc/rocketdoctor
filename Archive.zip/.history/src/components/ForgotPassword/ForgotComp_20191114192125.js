import React from 'react'
// import PropTypes from 'prop-types'

const SignIn = () => {
  return (
    <div>signin</div>
  )
}

SignIn.propTypes = {
}

export default SignIn;

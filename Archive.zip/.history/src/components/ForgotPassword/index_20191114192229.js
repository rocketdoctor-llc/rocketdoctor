import React from 'react';
import PropTypes from 'prop-types';
import AuthLayout from 'shared/AuthLayout';
import AuthSideBar from "shared/AuthSideBar";
import { Row, Col } from 'react-bootstrap';
import ForgotComp from "./forgotComp";


const SignIn = () => {
  return (
    <AuthLayout>
      <Row>
        <Col xs={{ span: 6}}>
          <ForgotComp />
        </Col>
        <Col xs={{ span: 6}}>
          <AuthSideBar />
        </Col>
      </Row>
    </AuthLayout>
  )
}

SignIn.propTypes = {
  getList: PropTypes.func
}

export default SignIn

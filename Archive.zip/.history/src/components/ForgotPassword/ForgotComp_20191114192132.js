import React from 'react'
// import PropTypes from 'prop-types'

const ForgotComp = () => {
  return (
    <div>ForgotComp</div>
  )
}

ForgotComp.propTypes = {
}

export default ForgotComp;

import React from 'react'
// import PropTypes from 'prop-types'
import Layout from 'common/Layout'
import { Container, Row, Col } from 'react-bootstrap';
import TitleHead from 'common/TitleHead/titleHead';

const Careers = () => {
  return (
    <Layout>
        <div className="outer-body">
            <TitleHead titleHead={"About us"} />
            <Container className="page-content">
                <Row className="text-center">
                    <Col>
                        <h2>Careers</h2>
                    </Col>
                </Row>
                <Row>
                    <Col xs={4}>
                        <h3>C.K. TEEWARY</h3>
                        <p>Founder</p>
                    </Col>
                    <Col  xs={4}>
                        <h3>C.K. TEEWARY</h3>
                        <p>Founder</p>
                    </Col>
                    <Col  xs={4}>
                        <h3>DEEPALI KATARIA</h3>
                        <p>UX / UI Designer</p>
                    </Col>
                </Row>
            </Container>
        </div>
    </Layout>
  )
}

Careers.propTypes = {
}

export default Careers;

import React from 'react';
import {  Row, Col, Container } from 'react-bootstrap';
import UploadImage from './../../images/uploadImage.svg';

const FourthSection = () => {
    return (
      <Container>
        <Row className="why-head">
            <Col xs={"12"} className="text-center">
                <h2 className="text-center text-heading">Why to Choose RocketDoctor App</h2>
            </Col>
            </Row>
            <Row className="why-bottom">
            <Col xs={4} className="text-center">
                <img src={UploadImage} alt="ChatIcon" />
                <div>
                <p>Explain your health issue</p>
                </div>                        
            </Col>
            <Col  xs={4} className="text-center">
                <img src={UploadImage} alt="ChatIcon" />
                <div>
                <p>Upload image  of problem</p>
                </div>
            </Col>
            <Col  xs={4} className="text-center">
                <img src={UploadImage} alt="ChatIcon" />
                <div>
                <p>Talk to Doctor</p>
                </div>
            </Col>
            <Col  xs={4} className="text-center">
                <img src={UploadImage} alt="ChatIcon" />
                <div>
                <p>Get E-prescription</p>
                </div>
            </Col>
        </Row>
      </Container>
    )
}

FourthSection.propTypes = {
}

export default FourthSection;
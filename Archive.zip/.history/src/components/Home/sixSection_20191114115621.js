import React from 'react';
import { Row, Col, Button } from 'react-bootstrap';
import { SixDivSection }  from './style';
import { Nphone } from '../../images/nphone.js';

const SixSection = () => {
  return (
    <SixDivSection>
      <Row>
        <Col md={{ span: 6 }}>
          <div>
            <img src={Nphone} alt="nphone" />
          </div>
        </Col>
        <Col md={{ span: 6 }}>
          <div>
            <h2>Get a Specialised Doctor Consultancy</h2>
            <p>We are here to help you in finding the best doctor for your problems</p>
            <Button className="outline-dark-btn">Talk To A Doctor</Button>
          </div>
        </Col>
      </Row>      
    </SixDivSection>
  )
}

SixSection.propTypes = {
}

export default SixSection;
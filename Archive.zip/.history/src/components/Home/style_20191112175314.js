import styled from 'styled-components';

export const FirstDivSection = styled.div`
  position: relative;
  left: 0%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  display: flex;
  width: 100%;
  min-height: 90vh;
  margin-top: 60px;
  justify-content: space-around;
  background-color: #f5f5f5;
  background-image: url(https://uploads-ssl.webflow.com/5dbaa0e…/5dc520e…_553002-PK371J-895.jpg');
  background-position: 0% 0%;
  background-size: cover;
  background-repeat: no-repeat;
`;
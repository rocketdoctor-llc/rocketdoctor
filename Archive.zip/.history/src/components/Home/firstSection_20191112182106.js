import React from 'react';
import { Row, Col } from 'react-bootstrap';
import { FirstDivSection, InnerDiv }  from './style';

const FirstSection = () => {
  return (
    <FirstDivSection>
      <Row>
        <Col md={{ span: 6, offset: 3 }}>
          <InnerDiv>
            <h1>When you need answers, our selected doctors can help.</h1>
          </InnerDiv>
        </Col>
      </Row>
      
    </FirstDivSection>
  )
}

FirstSection.propTypes = {
}

export default FirstSection;
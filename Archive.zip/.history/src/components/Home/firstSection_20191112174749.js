import React from 'react';
import { FirstDivSection }  './style.js';

const FirstSection = () => {
    return (
      <FirstDivSection />
    )
}

FirstSection.propTypes = {
}

export default FirstSection;
import React from 'react';

const SecondSection = () => {
    return (
      <>
      second Section
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';

const SecondSection = () => {
    return (
      <>
        <Container>
          <Row className="work-head">
            <Col xs={"12"}>
                <h2 className="text-center">How It Works</h2>
            </Col>
            <Col>
              <h2>Providing you with the best care.</h2>
              <Button variant="outline-primary">See A Doctor</Button>
            </Col>
          </Row>
        </Container>
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
import React from 'react';
import { Container } from 'react-bootstrap';

const SecondSection = () => {
    return (
      <>
        <Container>
          sdfsdf
        </Container>
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
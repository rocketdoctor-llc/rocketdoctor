import React from 'react';

const FirstSection = () => {
    return (
      <>
        <div style={{ backgroundImage: `url(require("`https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc520eee681dfbab3dc6fea_553002-PK371J-895.jpg`"))` }}>

        </div>
      </>
    )
}

FirstSection.propTypes = {
}

export default FirstSection;
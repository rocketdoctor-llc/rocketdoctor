import React from 'react';
import { Row, Col } from 'react-bootstrap';
import { ThirdDivSection } from './style';
const FourthSection = () => {
    return (
      <ThirdDivSection> 
        <Row>
          <Col md={{ span: 6, offset: 6 }}>
            <h2>When you need answers, our selected doctors can help.</h2>
          </Col>
        </Row>    
      </ThirdDivSection>
    )
}

FourthSection.propTypes = {
}

export default FourthSection;
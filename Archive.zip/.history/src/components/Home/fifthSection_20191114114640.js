import React from 'react';
import {  Row, Col, Container } from 'react-bootstrap';
import Stopwatch from './../../images/stopwatch.svg';
import { FifthDivSection } from './style';

const FifthSection = () => {
    return (
        <FifthDivSection fluid>
            <Row className="text-head-home">
                <Col xs={"12"} className="text-center mb-3">
                    <h2 className="text-center text-heading">Frequentaly Asked Questions</h2>
                </Col>
            </Row>
            <Row className="faq-bottom">
                <Col xs={4} className="text-center mb-3">
                    <div className="stop-box">
                        <h4>Why to Choose RocketDoctor App?</h4>
                        <div>
                        <p>Fastest Doctor Response</p>
                        </div>                    
                    </div>    
                </Col>
                <Col  xs={4} className="text-center mb-3">
                    <div className="stop-box">
                        <h4>Why to Choose RocketDoctor App?</h4>
                        <div>
                            <p>Doctors 24/7</p>
                        </div>
                    </div>
                </Col>
                <Col  xs={4} className="text-center mb-3">
                    <div className="stop-box">
                        <h4>Why to Choose RocketDoctor App?</h4>
                        <div>
                            <p>Experienced & Specialised</p>
                        </div>
                    </div>
                </Col>           
            </Row>
        </FifthDivSection>
    )
}

FifthSection.propTypes = {
}

export default FifthSection;
import React from 'react'
import PropTypes from 'prop-types'
import Button from 'react-bootstrap/Button';
import Layout from 'common/Layout'
import { pushNotification } from 'utils/notifications'
import Texts from 'constants/staticText'

const Home = (props) => {
  const { getList } = props
  return (
    <Layout>
      
    </Layout>
  )
}

Home.propTypes = {
  getList: PropTypes.func
}

export default Home

import React from 'react';
import { Row, Col, Button } from 'react-bootstrap';
import { FirstDivSection, InnerDiv }  from './style';

const FirstSection = () => {
  return (
    <FirstDivSection>
      <Row>
        <Col md={{ span: 6 }}>
          <InnerDiv>
            <h1>Get a Specialised Doctor Consultancy</h1>
            <Button variant="outline-primary">Find Doctor</Button>
          </InnerDiv>
        </Col>
      </Row>      
    </FirstDivSection>
  )
}

FirstSection.propTypes = {
}

export default FirstSection;
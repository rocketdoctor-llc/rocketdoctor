import React from 'react';
import PropTypes from 'prop-types'

const FirstSection = (props) => {
    const { getList } = props
    return (
      <Layout>
        
      </Layout>
    )
}

FirstSection.propTypes = {
getList: PropTypes.func
}

export default FirstSection;
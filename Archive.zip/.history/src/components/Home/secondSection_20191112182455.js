import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const SecondSection = () => {
    return (
      <>
        <Container>
          <Row>
            <Col>first</Col>
            <Col>Second</Col>
          </Row>
        </Container>
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
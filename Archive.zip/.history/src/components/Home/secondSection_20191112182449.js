import React from 'react';
import { Container, Row } from 'react-bootstrap';

const SecondSection = () => {
    return (
      <>
        <Container>
          <Row>
            <Col>first</Col>
            <Col>Second</Col>
          </Row>
        </Container>
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
import React from 'react';

const ThirdSection = () => {
    return (
      <>
      first Section
      </>
    )
}

ThirdSection.propTypes = {
}

export default ThirdSection;
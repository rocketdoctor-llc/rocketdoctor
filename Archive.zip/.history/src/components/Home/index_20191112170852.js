import React from 'react'
import PropTypes from 'prop-types'
// import Button from 'react-bootstrap/Button';
import Layout from 'common/Layout'
// import { pushNotification } from 'utils/notifications'
// import Texts from 'constants/staticText'
import FirstSection from "./firstSection";
import SecondSection from "./secondSection";
import ThirdSection from "./thirdSection";
import './home.scss';

const Home = () => {
  return (
    <Layout>
      <FirstSection />
      <SecondSection />
      <ThirdSection />
    </Layout>
  )
}

Home.propTypes = {
  getList: PropTypes.func
}

export default Home

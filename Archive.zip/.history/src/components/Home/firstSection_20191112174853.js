import React from 'react';
import { FirstDivSection }  './style';

const FirstSection = () => {
  return (
    <FirstDivSection />
  )
}

FirstSection.propTypes = {
}

export default FirstSection;
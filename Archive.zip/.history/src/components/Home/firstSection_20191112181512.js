import React from 'react';
import { FirstDivSection, InnerDiv }  from './style';

const FirstSection = () => {
  return (
    <FirstDivSection>
      <InnerDiv>
        <span>When you need answers, our selected doctors can help.</span>
      </InnerDiv>
    </FirstDivSection>
  )
}

FirstSection.propTypes = {
}

export default FirstSection;
import React from 'react';

const FirstSection = () => {
    return (
      <>
      first Section
      </>
    )
}

FirstSection.propTypes = {
}

export default FirstSection;
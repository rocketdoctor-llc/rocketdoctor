import React from 'react';

const FirstSection = (props) => {
    const { getList } = props
    return (
      <Layout>
        
      </Layout>
    )
}

FirstSection.propTypes = {
getList: PropTypes.func
}

export default FirstSection;
import React from 'react';
import PropTypes from 'prop-types'

const FirstSection = () => {
    return (
      <>
      first Section
      </>
    )
}

FirstSection.propTypes = {
}

export default FirstSection;
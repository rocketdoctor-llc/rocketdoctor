import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';

const SecondSection = () => {
    return (
      <>
        <Container fluid={true}>
         
        </Container>
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
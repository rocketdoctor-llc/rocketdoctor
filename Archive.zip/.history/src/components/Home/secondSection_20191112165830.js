import React from 'react';

const SecondSection = () => {
    return (
      <>
      first Section
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
import styled from 'styled-components';
import SlideView from '../../images/slideView.svg';
export const FirstDivSection = styled.div`  
  background-image: url("${SlideView}");
  height: 511px;
`;

export const InnerDiv = styled.div`
  padding: 10px 0px 20px 20px;
  margin-top: 109px;
  margin-left: 150px;
  font-family: 'Hind';
  font-style: normal;
  h2 {
    width: 417px;   
    font-weight: 600;
    font-size: 48px;
    line-height: 124%;
    color: #000000;
  }
  p {
    width: 417px;
  }
`;
export const ThirdDivSection = styled.div`
  position: relative;
  left: 0%;
  top: 0%;
  right: 0%;
  bottom: 0%;
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display: flex;
  width: 100%;
  min-height: 90vh;
  margin-top: 60px;
  -webkit-justify-content: space-around;
  -ms-flex-pack: distribute;
  justify-content: space-around;
  background-color: #f5f5f5;
  background-image: url("https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc3979f6a906d00393145c8_O6RBXH0.jpg");
  background-position: 0% 0%;
  background-size: cover;
  background-repeat: no-repeat;
`;

export const FourthDivSection = styled.div`
  min-height: auto;
  padding-top: 40px;
  padding-bottom: 40px;
  background-color: #f4f4f4;
`;
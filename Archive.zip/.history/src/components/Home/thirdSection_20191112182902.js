import React from 'react';
import { ThirdDivSection } from './style';
const ThirdSection = () => {
    return (
      <ThirdDivSection />
    )
}

ThirdSection.propTypes = {
}

export default ThirdSection;
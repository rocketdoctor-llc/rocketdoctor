import React from 'react';
import { FirstDivSection }  from './style';

const FirstSection = () => {
  return (
    <FirstDivSection />
  )
}

FirstSection.propTypes = {
}

export default FirstSection;
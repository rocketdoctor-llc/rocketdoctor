import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import ChatIcon from './../../images/chatIcon.svg';

const SecondSection = () => {
    return (
      <>
        <Container>
          <Row className="work-head">
            <Col xs={"12"}>
                <h2 className="text-center">How It Works</h2>
            </Col>
            <Col xs={3}>
              <img src={ChatIcon} alt="ChatIcon" />
              <div>
                <p>Founder</p>
              </div>                        
            </Col>
            <Col  xs={3}>
              <img src={ChatIcon} alt="ChatIcon" />
              <div>
                <p>Backend and Blockchain Developer</p>
              </div>
            </Col>
            <Col  xs={3}>
              <img src={ChatIcon} alt="ChatIcon" />
              <div>
                <p>UX / UI Designer</p>
              </div>
            </Col>
            <Col  xs={3}>
              <img src={ChatIcon} alt="ChatIcon" />
              <div>
                <p>UX / UI Designer</p>
              </div>
            </Col>
          </Row>
        </Container>
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
import React from 'react';
import { Row, Col } from 'react-bootstrap';
import { ThirdDivSection } from './style';
import ChatIcon from './../../images/chatIcon.svg';
import { Container } from 'react-bootstrap';
const ThirdSection = () => {
    return (
      <Container>
        <Row className="work-head">
          <Col xs={"12"} className="text-center">
            <h2 className="text-center text-heading">How It Works</h2>
          </Col>
        </Row>
        <Row className="work-bottom">
          <Col xs={2} className="text-center">
            <img src={ChatIcon} alt="ChatIcon" />
            <div>
              <p>Explain your health issue</p>
            </div>                        
          </Col>
          <Col xs={2} className="text-center">
            <img src={ChatIcon} alt="ChatIcon" />
            <div>
              <p>Explain your health issue</p>
            </div>                        
          </Col>
          <Col xs={2} className="text-center">
            <img src={ChatIcon} alt="ChatIcon" />
            <div>
              <p>Explain your health issue</p>
            </div>                        
          </Col>
          <Col xs={2} className="text-center">
            <img src={ChatIcon} alt="ChatIcon" />
            <div>
              <p>Explain your health issue</p>
            </div>                        
          </Col>
          <Col xs={2} className="text-center">
            <img src={ChatIcon} alt="ChatIcon" />
            <div>
              <p>Explain your health issue</p>
            </div>                        
          </Col>
          <Col xs={2} className="text-center">
            <img src={ChatIcon} alt="ChatIcon" />
            <div>
              <p>Explain your health issue</p>
            </div>                        
          </Col>
        </Row>
      </Container>
    )
}

ThirdSection.propTypes = {
}

export default ThirdSection;
import React from 'react';
import { Row, Col, Container } from 'react-bootstrap';
import { ThirdDivSection } from './style';
const FourthSection = () => {
    return (
      <ThirdDivSection> 
        <Container>
            <Row>
                <Col>
                    <img src="https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc251ebec127316a768def6_mobile-frame.png" alt="" />
                </Col>
                <Col>
                    <h2>Providing you with the best care.</h2>
                    <Button variant="outline-primary">See A Doctor</Button>
                </Col>
            </Row>
        </Container>
      </ThirdDivSection>
    )
}

FourthSection.propTypes = {
}

export default FourthSection;
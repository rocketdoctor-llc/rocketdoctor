import React from 'react';
import { Row, Col } from 'react-bootstrap';
import { ThirdDivSection } from './style';
const ThirdSection = () => {
    return (
      <ThirdDivSection> 
        <Row className="work-head">
          <Col xs={"12"} className="text-center">
            <h2 className="text-center text-heading">How It Works</h2>
          </Col>
        </Row>
        <Row>
          <Col>
            <h2>When you need answers, our selected doctors can help.</h2>
          </Col>
        </Row>    
      </ThirdDivSection>
    )
}

ThirdSection.propTypes = {
}

export default ThirdSection;
import React from 'react';
import { FirstDivSection, InnerDiv }  from './style';

const FirstSection = () => {
  return (
    <FirstDivSection>
      <InnerDiv>
        <h1>When you need answers, our selected doctors can help.</h1>
      </InnerDiv>
    </FirstDivSection>
  )
}

FirstSection.propTypes = {
}

export default FirstSection;
import React from 'react';
import { Row, Col, Button } from 'react-bootstrap';
import { SixDivSection }  from './style';
import Nphone from '../../images/nphone.svg';

const SixSection = () => {
  return (
    <SixDivSection>
      <Row>
        <Col md={{ span: 6 }}>
          <div>
            <img src={Nphone} alt="nphone" />
          </div>
        </Col>
        <Col md={{ span: 6 }}>
          <div>
            <h2>RocketDoctor App is available on Android and MAC Devices</h2>
            <p>Download now for most cost effective way to get world-class care</p>
            <Button className="outline-dark-btn">Talk To A Doctor</Button>
          </div>
        </Col>
      </Row>      
    </SixDivSection>
  )
}

SixSection.propTypes = {
}

export default SixSection;
import React from 'react';
import { Row, Col, Container, Button, Form, FormControl } from 'react-bootstrap';
import { FourthDivSection } from './style';
const FourthSection = () => {
    return (
      <FourthDivSection> 
        <Container>
            <Row>
                <Col>
                    <img src="https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc251ebec127316a768def6_mobile-frame.png" alt="" />
                </Col>
                <Col>
                    <h2>Download the Rocketdoctor app</h2>
                    <div>Book appointments and health checkups.Order medicines and consult doctors online</div>
                    <Button variant="outline-primary">See A Doctor</Button>
                    <Form inline>
                        <FormControl type="text" placeholder="Search" className="mr-sm-2" />
                        <Button variant="outline-success">Search</Button>
                    </Form>
                </Col>
            </Row>
        </Container>
      </FourthDivSection>
    )
}

FourthSection.propTypes = {
}

export default FourthSection;
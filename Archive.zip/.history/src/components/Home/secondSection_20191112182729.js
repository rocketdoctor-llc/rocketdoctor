import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';

const SecondSection = () => {
    return (
      <>
        <Container>
          <Row>
            <Col>
              <img src="https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc515763441071dac69daeb_side-img.jpg" alt="" />
            </Col>
            <Col>
              <h2>Providing you with the best care.</h2>
              <Button variant="outline-primary">See A Doctor</Button>
            </Col>
          </Row>
        </Container>
      </>
    )
}

SecondSection.propTypes = {
}

export default SecondSection;
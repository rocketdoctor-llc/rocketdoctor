import React from 'react';

const ThirdSection = () => {
    return (
      <>
      third Section
      </>
    )
}

ThirdSection.propTypes = {
}

export default ThirdSection;
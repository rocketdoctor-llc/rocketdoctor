import React from 'react';
import { FirstDivSection, InnerDiv }  from './style';

const FirstSection = () => {
  return (
    <FirstDivSection>
      <InnerDiv />
    </FirstDivSection>
  )
}

FirstSection.propTypes = {
}

export default FirstSection;
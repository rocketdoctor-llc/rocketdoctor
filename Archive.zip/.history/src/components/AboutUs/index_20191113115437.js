import React from 'react'
// import PropTypes from 'prop-types'
import Layout from 'common/Layout'
import { Container, Row, Col } from 'react-bootstrap';

const AboutUs = () => {
  return (
    <Layout>
        <div className="outer-body">
            <div className="title-wrp">
                <Container>
                    <Row>
                        <Col>
                            <h1 className="banner-title"></h1>
                        </Col>
                    </Row>
                </Container>
            </div>
            <div className="page-content">

            </div>
        </div>
      About Us page
    </Layout>
  )
}

AboutUs.propTypes = {
}

export default AboutUs;

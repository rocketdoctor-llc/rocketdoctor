import React from 'react'
import PropTypes from 'prop-types'
import Layout from 'common/Layout'

const AboutUs = () => {
  return (
    <Layout>
      About Us page
    </Layout>
  )
}

AboutUs.propTypes = {
  getList: PropTypes.func
}

export default AboutUs

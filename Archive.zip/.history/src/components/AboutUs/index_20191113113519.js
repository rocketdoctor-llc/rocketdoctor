import React from 'react'
import PropTypes from 'prop-types'
import Layout from 'common/Layout'

const AboutUs = () => {
  return (
    <Layout>
      About Us page
    </Layout>
  )
}

AboutUs.propTypes = {
}

export default AboutUs;

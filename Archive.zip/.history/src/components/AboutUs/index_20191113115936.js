import React from 'react'
// import PropTypes from 'prop-types'
import Layout from 'common/Layout'
import { Container, Row, Col } from 'react-bootstrap';

const AboutUs = () => {
  return (
    <Layout>
        <div className="outer-body">
            <div className="title-wrp">
                <Container>
                    <Row>
                        <Col>
                            <h1 className="banner-title">About us</h1>
                        </Col>
                    </Row>
                </Container>
            </div>
            <Container className="page-content">
                <Row className="justify-content-md-center text-center">
                    <Col>
                        <h2>Company Information</h2>
                    </Col>
                </Row>
            </Container>
        </div>
    </Layout>
  )
}

AboutUs.propTypes = {
}

export default AboutUs;

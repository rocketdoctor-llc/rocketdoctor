import React from 'react'
// import PropTypes from 'prop-types'

const ForgotPassword = () => {
  return (
    <div>ForgotPassword</div>
  )
}

ForgotPassword.propTypes = {
}

export default SignIn;

import React from 'react'
import PropTypes from 'prop-types'
import AuthLayout from 'shared/AuthLayout'
import { Row, Col } from 'react-bootstrap';
// import SignInComp from "./signInComp";

const Home = () => {
  return (
    <AuthLayout>
        <Row>
            <Col xs={{ span: 6}}>Login Side</Col>
            <Col xs={{ span: 6}}>Rightside</Col>
        </Row>
    </AuthLayout>
  )
}

Home.propTypes = {
  getList: PropTypes.func
}

export default Home

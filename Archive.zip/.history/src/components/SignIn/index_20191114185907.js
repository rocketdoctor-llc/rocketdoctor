import React from 'react'
import PropTypes from 'prop-types'
import AuthLayout from 'shared/AuthLayout'
import SignInComp from "./signInComp";

const Home = () => {
  return (
    <AuthLayout>
        <SignInComp />
    </AuthLayout>
  )
}

Home.propTypes = {
  getList: PropTypes.func
}

export default Home

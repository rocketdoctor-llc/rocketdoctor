import React from 'react'
import PropTypes from 'prop-types'
import AuthLayout from 'shared/AuthLayout'
import FirstSection from "./firstSection";
import SecondSection from "./secondSection";
import ThirdSection from "./thirdSection";
import FourthSection from "./fourthSection";
import FifthSection from "./fifthSection";
import SixSection from "./sixSection";

const Home = () => {
  return (
    <AuthLayout>
      <FirstSection />
      <SecondSection />
      <ThirdSection />
      <FourthSection />
      <FifthSection />
      <SixSection />
    </AuthLayout>
  )
}

Home.propTypes = {
  getList: PropTypes.func
}

export default Home

import React from 'react';
import { Row, Col, Container, Image } from 'react-bootstrap';

const TitleHead = (props) => (
    <div className="title-wrp">
        <Container>
            <Row>
                <Col>
                    <h1 className="banner-title">About us</h1>
                </Col>
            </Row>
        </Container>
    </div>
)

export default TitleHead

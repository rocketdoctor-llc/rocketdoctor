import React from 'react';
import { Row, Col, Container, Image } from 'react-bootstrap';

const TitleHead = (props) => (
)

export default TitleHead

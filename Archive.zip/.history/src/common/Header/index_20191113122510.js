import React from 'react';
import PropTypes from 'prop-types';
import {Navbar, Nav, Container} from 'react-bootstrap';
import { Link } from 'react-router-dom';


const Header = (props) => {
  return (
	<div className="outer-header">
		<Container fluid={false}>
			<Navbar>
				<Navbar.Brand href="/">
					<img src="https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc3d0bd429c1a993af89746_without-checkROCEKT-DOCTOR.png" alt=""/>
				</Navbar.Brand>
				<Navbar.Toggle aria-controls="basic-navbar-nav" />
				<Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
					<Nav>
						<Link className="nav-link" to="/">Home</Link>
						<Link className="nav-link" to="/whitepaper">Whitepaper</Link>
						<Link className="nav-link" to="/about-us">About Us</Link>
						<Link className="nav-link" to="/our-team">Team</Link>
						<Link className="nav-link" to="/careers">Careers</Link>
						<Link className="nav-link" to="/contact-us">Contact us</Link>
					</Nav>
				</Navbar.Collapse>
			</Navbar>
		</Container>
	</div>
  )
}

Header.propTypes = {
  showBackground: PropTypes.bool
}

export default Header

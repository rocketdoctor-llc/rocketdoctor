import React from 'react'
import PropTypes from 'prop-types'
import {Navbar, Nav, Form, NavDropdown, FormControl, Button, Container} from 'react-bootstrap'


const Header = (props) => {
  return (
	<div className="outer-header">
		<Container fluid={false}>
			<Navbar>
				<Navbar.Brand href="/"><img src="https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc3d0bd429c1a993af89746_without-checkROCEKT-DOCTOR.png" width="40" height="40" alt=""/></Navbar.Brand>
				<Navbar.Toggle aria-controls="basic-navbar-nav" />
				<Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
					<Nav>
						<Nav.Link href="/">Home</Nav.Link>
						<Nav.Link href="/whitepaper">Whitepaper</Nav.Link>
						<Nav.Link href="/whitepaper">About Us</Nav.Link>
						<Nav.Link href="/whitepaper">Team</Nav.Link>
						<Nav.Link href="/whitepaper">Careers</Nav.Link>
						<Nav.Link href="/whitepaper">Contact us</Nav.Link>
						{/* <NavDropdown title="Dropdown" id="basic-nav-dropdown">
							<NavDropdown.Item href="#action/3.1">Action</NavDropdown.Item>
							<NavDropdown.Item href="#action/3.2">Another action</NavDropdown.Item>
							<NavDropdown.Item href="#action/3.3">Something</NavDropdown.Item>
							<NavDropdown.Divider />
							<NavDropdown.Item href="#action/3.4">Separated link</NavDropdown.Item>
						</NavDropdown> */}
					</Nav>
				</Navbar.Collapse>
			</Navbar>
		</Container>
	</div>
  )
}

Header.propTypes = {
  showBackground: PropTypes.bool
}

export default Header

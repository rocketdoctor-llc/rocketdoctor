import React from 'react';
import { Row, Col, Container, Image } from 'react-bootstrap';

const Footer = (props) => (
  <>
    <Container>
      <Row>
        <Col md={{ span: 3 }}>
            <Image src="https://uploads-ssl.webflow.com/5dbaa0ecaf8471530748d881/5dc5354dd422e8282621ff4c_logo.png" alt="" class="" thumbnail />
            <div>
              <p>© 2019 Rocketdoctor LLC, all rights reserved</p>
            </div>
        </Col>
        <Col md={{ span: 9 }}>
          <div></div>
          <div></div>
        </Col>
      </Row>
    </Container>
  </>
)

export default Footer

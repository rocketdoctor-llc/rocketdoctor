import React from 'react';
import { Row, Col } from 'react-bootstrap';

const Footer = (props) => (
  <>
    <Row>
      <Col md={{ span: 3 }}>sdf</Col>
      <Col md={{ span: 9 }}>sdfsfsdf</Col>
    </Row>
  </>
)

export default Footer

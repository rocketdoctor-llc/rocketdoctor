import React from 'react'

const Footer = (props) => (
  <>
    <Row>
      <Col md={{ span: 3 }}>sdf</Col>
      <Col md={{ span: 9 }}>sdfsfsdf</Col>
    </Row>
  </>
)

export default Footer

import React from 'react';
import { Row, Col } from 'react-bootstrap';

const Footer = (props) => (
  <>
    <Continer>
      <Row>
        <Col md={{ span: 3 }}>sdf</Col>
        <Col md={{ span: 9 }}>sdfsfsdf</Col>
      </Row>
    </Continer>
  </>
)

export default Footer

import React from 'react';
import { Row, Col, Container } from 'react-bootstrap';

const Footer = (props) => (
  <>
    <Container>
      <Row>
        <Col md={{ span: 3 }}>sdf</Col>
        <Col md={{ span: 9 }}>sdfsfsdf</Col>
      </Row>
    </Container>
  </>
)

export default Footer
